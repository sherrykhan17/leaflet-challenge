// API key
const API_KEY = "pk.eyJ1Ijoic2hlcnJ5a2hhbjE3IiwiYSI6ImNra3N5a25odzBjdHQybnJ1MXd5a3pnMXIifQ.I6QQU_F87MiHhQOqWPK19w";
